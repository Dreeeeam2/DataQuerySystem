Chinese（中文）
这是一个档案管理系统，里面的参数可以自定义，例如（姓名 年龄 文化程度）
不要删除这个文件夹下的任何一个文件！！！！！！！
功能介绍：
1 . 创建个人档案
2 . 编辑个人档案（两种模式可选）
       （1）程序内编辑
       （2）程序外编辑（记事本文件内）
3.读取个人档案（建议程序内查看，快捷，方便）
------------------------------------------------------------------
使用方式：
1.点击“Runner”文件夹
 （创建步骤）
   1.点击CreateFileMainRun文件，输入创建的文件名，随后开始创建
 （编辑步骤）
   1.点击FileWriterMainRun文件，根据提示输入各项基本参数（扩展参数在最后一个问题里写），随后开始写入
   (读取步骤）
   1.点击FileReaderMainRunner文件，输入档案归属者姓名，随后下面一行就是档案信息。
------------------------------------------------------------------
DAC技术协会荣誉出品
DDA-Soft Corp [c] 版权声明
 by Dream2
------------------------------------------------------------------
English
This is a file management system where the parameters can be customized, such as (name, age, education level)
DON'T DELETE ANY FILE IN THIS FLODER!!!!!!!!!!
Function Introduction:
1 Create a profile
2 Edit personal profile (two modes available)
(1) In-program editing
(2) Out of program editing (within Notepad files)
3. Read personal files (recommended for quick and convenient viewing within the program)
------------------------------------------------------------------
Usage:
1. Click on the 'Runner' folder
(Creation steps)
1. Click on the Create FileMainRun file, enter the name of the created file, and then start creating it
(Editing steps)
1. Click on the FileWriterMainRun file, enter various basic parameters according to the prompts (write extension parameters in the last question), and then start writing
(Reading steps)
1. Click on the FileReaderMainRunner file, enter the name of the file owner, and the following line will contain the file information.
------------------------------------------------------------------
DAC Technology Association Honorary Product
DDA Soft Corp [c] Copyright Notice
By Dream2
------------------------------------------------------------------