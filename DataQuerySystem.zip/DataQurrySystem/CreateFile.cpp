#include <bits/stdc++.h>
using namespace std;
int main(){
    ofstream ofile;int a;
    string name;
         std::cout << "DDA-Soft Corp [c]"<< std::endl;
          std::cout << "FileQuerySystem v2.0.1"<< std::endl;
               std::cout << "Soft number: Fqs-05-Windows"<< std::endl;
cout << "file name?" << endl;
cin >> name;
    cout << "Create Files..." << endl;
    name = name + ".txt";
ofile.open(name);
cout << "Create Over!..." <<endl; 
cout << "Press any key to exit..."<<endl;
cin >> a;
}